#ifndef FINITE_DIFF_HPP
#define FINITE_DIFF_HPP

#include <cmath>
#include <vector>
#include <string>

// Target function and exact derivative
inline double u(double x)
{
    return std::sin(x);
}

inline double u_prime_exact(double x)
{
    return std::cos(x);
}

// Forward difference
inline double D_plus(double (*f)(double), double x, double h)
{
    return (f(x + h) - f(x)) / h;
}

// Backward difference
inline double D_minus(double (*f)(double), double x, double h)
{
    return (f(x) - f(x - h)) / h;
}

// Centered difference
inline double D_center(double (*f)(double), double x, double h)
{
    return (f(x + h) - f(x - h)) / (2.0 * h);
}

// Third-order one-sided difference
inline double D3(double (*f)(double), double x, double h)
{
    return (2.0 * f(x + h) + 3.0 * f(x) - 6.0 * f(x - h) + f(x - 2.0 * h)) / (6.0 * h);
}

// Compute pairwise observed orders
inline std::vector<double> pairwise_orders(const std::vector<double>& h, const std::vector<double>& tau)
{
    std::vector<double> p;
    for (size_t i = 0; i + 1 < h.size(); i++)
    {
        double t1 = std::fabs(tau[i]);
        double t2 = std::fabs(tau[i + 1]);
        double pval = std::log(t1 / t2) / std::log(h[i] / h[i + 1]);
        p.push_back(pval);
    }
    return p;
}

// Compute global slope by linear regression on log-log data
inline double global_slope(const std::vector<double>& h, const std::vector<double>& tau)
{
    size_t n = h.size();
    double sum_x = 0.0, sum_y = 0.0, sum_xx = 0.0, sum_xy = 0.0;
    for (size_t i = 0; i < n; i++)
    {
        double x = std::log(h[i]);
        double y = std::log(std::fabs(tau[i]));
        sum_x += x;
        sum_y += y;
        sum_xx += x * x;
        sum_xy += x * y;
    }
    double p = (n * sum_xy - sum_x * sum_y) / (n * sum_xx - sum_x * sum_x);
    return p;
}

#endif