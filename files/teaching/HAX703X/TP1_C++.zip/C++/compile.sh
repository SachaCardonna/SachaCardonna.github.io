g++ -std=c++17 -O2 tp1.cpp -o tp1
./tp1