#include <iostream>
#include <iomanip>
#include "finite_diff.hpp"

int main()
{
    double xbar = 1.0;
    double u1p = u_prime_exact(xbar);

    // Step sizes
    std::vector<double> h_values = { 1e-1, 5e-2, 1e-2, 5e-3, 1e-3 };

    // Schemes
    struct Scheme {
        std::string name;
        double (*method)(double (*)(double), double, double);
    };
    std::vector<Scheme> schemes = {
        {"D_plus (O(h))", D_plus},
        {"D_minus (O(h))", D_minus},
        {"D_center (O(h^2))", D_center},
        {"D3 (O(h^3))", D3}
    };

    // Compute errors
    std::cout << std::scientific << std::setprecision(6);
    std::cout << "Truncation errors (tau = approx - exact):\n";
    std::cout << "h\t";
    for (auto& sc : schemes) std::cout << sc.name << "\t";
    std::cout << "\n";

    std::vector<std::vector<double>> all_errors;
    for (size_t i = 0; i < h_values.size(); i++)
    {
        double h = h_values[i];
        std::cout << h << "\t";
        std::vector<double> errs;
        for (auto& sc : schemes)
        {
            double approx = sc.method(u, xbar, h);
            double tau = approx - u1p;
            errs.push_back(tau);
            std::cout << tau << "\t";
        }
        all_errors.push_back(errs);
        std::cout << "\n";
    }

    // Observed orders
    std::cout << "\nObserved orders (pairwise + global):\n";
    for (size_t j = 0; j < schemes.size(); j++)
    {
        std::vector<double> tau;
        for (size_t i = 0; i < h_values.size(); i++)
        {
            tau.push_back(all_errors[i][j]);
        }
        auto p_pairs = pairwise_orders(h_values, tau);
        double p_glob = global_slope(h_values, tau);

        std::cout << schemes[j].name << ":\n";
        std::cout << "  Pairwise orders: ";
        for (auto p : p_pairs) std::cout << p << " ";
        std::cout << "\n  Global slope: " << p_glob << "\n";
    }

    return 0;
}